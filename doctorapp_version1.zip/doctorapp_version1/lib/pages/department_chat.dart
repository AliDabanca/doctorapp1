import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: CommunityChatPage(departmentName: '',),
  ));
}



class CommunityChatPage extends StatelessWidget {
  final String departmentName;

  CommunityChatPage({required this.departmentName, super.key});

  final List<Map<String, String>> dummyMessages = [
    {
      'sender': 'Dr. Ayşe',
      'text': 'Toplantı saat 15:00’te başlayacak.',
      'time': '10:34',
    },
    {
      'sender': 'Ben', // bu mesaj bize ait gibi gösterilecek
      'text': 'Anladım, orada olacağım.',
      'time': '10:35',
    },
    {
      'sender': 'Dr. Mehmet',
      'text': 'Yeni hastanın MR sonuçları geldi.',
      'time': '10:36',
    },
    {
      'sender': 'Ben',
      'text': 'Sonuçları sistemde paylaştım.',
      'time': '10:37',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Text('$departmentName Community'),
        backgroundColor: Colors.blue.shade700,
        elevation: 4,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(12),
              itemCount: dummyMessages.length,
              itemBuilder: (context, index) {
                final msg = dummyMessages[index];
                final isMine = msg['sender'] == 'Ben';

                return Align(
                  alignment:
                  isMine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 6),
                    padding:
                    EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    constraints: BoxConstraints(maxWidth: 280),
                    decoration: BoxDecoration(
                      color: isMine
                          ? Colors.blue.shade100
                          : Colors.grey.shade300,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(16),
                        topRight: Radius.circular(16),
                        bottomLeft: Radius.circular(isMine ? 16 : 0),
                        bottomRight: Radius.circular(isMine ? 0 : 16),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (!isMine)
                          Text(
                            msg['sender'] ?? '',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.blue.shade900),
                          ),
                        SizedBox(height: 4),
                        Text(
                          msg['text'] ?? '',
                          style: TextStyle(fontSize: 16),
                        ),
                        SizedBox(height: 4),
                        Align(
                          alignment: Alignment.bottomRight,
                          child: Text(
                            msg['time'] ?? '',
                            style: TextStyle(
                                fontSize: 12, color: Colors.grey.shade600),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    enabled: false, // şimdilik pasif
                    decoration: InputDecoration(
                      hintText: 'Mesajınızı yazın...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                ),
                SizedBox(width: 8),
                IconButton(
                  onPressed: () {},
                  icon: Icon(Icons.send, color: Colors.grey),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
