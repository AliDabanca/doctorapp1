import 'package:flutter/material.dart';
import 'welcome_page.dart';
import 'my_profile.dart';
import 'community_page.dart';
import 'agenda_page.dart';

class HomePage extends StatelessWidget {
  final String hospitalName = "City Hospital";
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final currentTime = TimeOfDay.now();

    return Scaffold(
      backgroundColor: Color(0xFFE6F0FA),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 🏥 ÜST KISIM: Hastane adı, saat, çıkış butonu
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Hastane adı ve saat
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        hospitalName,
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue[900],
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Today - ${currentTime.format(context)}',
                        style: TextStyle(
                          color: Colors.blueGrey,
                        ),
                      ),
                    ],
                  ),

                  // Çıkış butonu
                  IconButton(
                    icon: Icon(Icons.logout, color: Colors.blue[800]),
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: Text("Exit"),
                          content: Text("Do you want to quit?"),
                          actions: [
                            TextButton(
                              child: Text("No"),
                              onPressed: () {
                                Navigator.pop(context); // dialog kapansın
                              },
                            ),
                            TextButton(
                              child: Text("Yes"),
                              onPressed: () {
                                // Firebase varsa: FirebaseAuth.instance.signOut();
                                Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => WelcomePage()),
                                      (route) => false,
                                );
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  )
                ],
              ),
              SizedBox(height: 30),

              // Ana butonlar
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  children: [
                    HomeButton(
                      title: 'My Profile',
                      icon: Icons.person,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => DoctorProfilePage()),
                        );
                      },
                    ),
                    HomeButton(
                      title: 'Agenda',
                      icon: Icons.calendar_month,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const DoctorAgendaPage()),
                        );
                      },
                    ),
                    HomeButton(
                      title: 'AI Assistant',
                      icon: Icons.smart_toy,
                      onTap: () {},
                    ),
                    HomeButton(
                      title: 'Community',
                      icon: Icons.forum,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => CommunityPage()),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// 🔹 Kutular
class HomeButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;

  const HomeButton({
    required this.title,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 10,
              offset: Offset(2, 4),
            ),
          ],
        ),
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: Colors.blue[700]),
            SizedBox(height: 16),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                color: Colors.blue[900],
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
