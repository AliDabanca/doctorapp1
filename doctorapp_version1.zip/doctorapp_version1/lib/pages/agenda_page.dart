import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DoctorAgendaPage extends StatefulWidget {
  const DoctorAgendaPage({super.key});

  @override
  State<DoctorAgendaPage> createState() => _DoctorAgendaPageState();
}

class _DoctorAgendaPageState extends State<DoctorAgendaPage> {
  DateTime selectedDate = DateTime.now();

  // Örnek randevular (doktorun kendi ajandası)
  final Map<String, List<Map<String, String>>> sampleAppointments = {
    '2025-05-28': [
      {'time': '09:00', 'patient': 'Ahmet Yılmaz', 'notes': 'Genel kontrol'},
      {'time': '11:00', 'patient': 'Ayşe Demir', 'notes': 'MR sonuçları'},
    ],
    '2025-05-29': [
      {'time': '10:30', 'patient': 'Mehmet Kara', 'notes': 'Tansiyon ölçümü'},
    ],
  };

  List<Map<String, String>> getAppointmentsForDate(DateTime date) {
    String key = DateFormat('yyyy-MM-dd').format(date);
    return sampleAppointments[key] ?? [];
  }

  void _selectDate() async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );

    if (picked != null) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final appointments = getAppointmentsForDate(selectedDate);
    final dayLabel = DateFormat('d MMMM y', 'tr').format(selectedDate);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ajandam'),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: _selectDate,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // Yeni randevu ekleme ekranına gidebilir
        },
        label: const Text("Yeni Randevu"),
        icon: const Icon(Icons.add),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              dayLabel,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            appointments.isEmpty
                ? const Center(child: Text("Bugün için randevu yok."))
                : Expanded(
              child: ListView.builder(
                itemCount: appointments.length,
                itemBuilder: (context, index) {
                  final a = appointments[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 16),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    elevation: 4,
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.blue[100],
                        child: Icon(Icons.access_time,
                            color: Colors.blue[700]),
                      ),
                      title: Text(
                        '${a['time']} - ${a['patient']}',
                        style:
                        const TextStyle(fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text(a['notes'] ?? ''),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}