import 'package:flutter/material.dart';
import 'department_chat.dart';
import 'my_profile.dart'; // DoctorProfilePage burada

class CommunityPage extends StatelessWidget {
  final List<Map<String, dynamic>> departments = [
    {'name': 'Cardiology', 'icon': Icons.favorite},
    {'name': 'Dermatology', 'icon': Icons.spa},
    {'name': 'Neurology', 'icon': Icons.psychology},
    {'name': 'Pediatrics', 'icon': Icons.child_care},
    {'name': 'Radiology', 'icon': Icons.camera_alt},
    {'name': 'Oncology', 'icon': Icons.healing},
    {'name': 'Orthopedics', 'icon': Icons.accessibility_new},
  ];

  CommunityPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Text('Departments'),
        backgroundColor: Colors.blue.shade700,
        actions: [
          IconButton(
            icon: Icon(Icons.person),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const DoctorProfilePage()),
              );
            },
          )
        ],
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: departments.length,
        itemBuilder: (context, index) {
          final dept = departments[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => CommunityChatPage(
                        departmentName: dept['name'])),
              );
            },
            child: Container(
              margin: EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue.shade100, Colors.blue.shade50],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade400,
                    blurRadius: 6,
                    offset: Offset(2, 4),
                  )
                ],
              ),
              child: ListTile(
                contentPadding:
                EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(dept['icon'], color: Colors.blue),
                ),
                title: Text(
                  dept['name'],
                  style: TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                trailing: Icon(Icons.arrow_forward_ios,
                    color: Colors.blue.shade300),
              ),
            ),
          );
        },
      ),
    );
  }
}