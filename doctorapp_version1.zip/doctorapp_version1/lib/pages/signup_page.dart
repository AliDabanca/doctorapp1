import 'package:flutter/material.dart';
import 'home_page.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'welcome_page.dart';

class SignUpPage extends StatefulWidget {
  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final ageController = TextEditingController();

  String? selectedDepartment;
  bool isLoading = false;

  final List<String> departments = [
    'Cardiology',
    'Dermatology',
    'Neurology',
    'Pediatrics',
    'Psychiatry',
    'Internal Medicine',
    'Orthopedics',
    'ENT',
    'Ophthalmology',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFFE6F0FA),
    appBar: AppBar(
    backgroundColor: Colors.transparent,
    elevation: 0,
    iconTheme: IconThemeData(color: Colors.blue[900]),
    ),
    body: Center(
    child: SingleChildScrollView(
    padding: const EdgeInsets.symmetric(horizontal: 32),
    child: Column(
    children: [
    Text(
    'Sign Up',
    style: TextStyle(
    fontSize: 26,
    fontWeight: FontWeight.bold,
    color: Colors.blue[900],
    ),
    ),
    const SizedBox(height: 32),
      // Full Name
      TextField(
        controller: nameController,
        decoration: inputDecoration('Full Name', Icons.person),
      ),
      const SizedBox(height: 16),

      // Age
      TextField(
        controller: ageController,
        keyboardType: TextInputType.number,
        decoration: inputDecoration('Age', Icons.cake),
      ),
      const SizedBox(height: 16),

      // Department
      DropdownButtonFormField<String>(
        value: selectedDepartment,
        hint: const Text("Select Department"),
        items: departments
            .map((dept) => DropdownMenuItem(
          value: dept,
          child: Text(dept),
        ))
            .toList(),
        onChanged: (value) {
          setState(() {
            selectedDepartment = value;
          });
        },
        decoration: inputDecoration('Department', Icons.local_hospital),
      ),
      const SizedBox(height: 16),

      // Email
      TextField(
        controller: emailController,
        decoration: inputDecoration('Email Address', Icons.email),
      ),
      const SizedBox(height: 16),

      // Password
      TextField(
        controller: passwordController,
        obscureText: true,
        decoration: inputDecoration('Password', Icons.lock),
      ),
      const SizedBox(height: 24),

      // Sign Up Button
      SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: isLoading ? null : _signUp,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue[800],
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: isLoading
              ? const CircularProgressIndicator(
              color: Colors.white, strokeWidth: 2)
              : const Text('Sign up', style: TextStyle(fontSize: 16)),
        ),
      ),

      const SizedBox(height: 10),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text("Already have an account?"),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Log in'),
          )
        ],
      )
    ],
    ),
    ),
    ),
    );
  }

  InputDecoration inputDecoration(String hint, IconData icon) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: Colors.white,
      prefixIcon: Icon(icon),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    );
  }

  Future<void> _signUp() async {
    final name = nameController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text.trim();
    final age = ageController.text.trim();
    final department = selectedDepartment;

    if (name.isEmpty ||
        email.isEmpty ||
        password.isEmpty ||
        age.isEmpty ||
        department == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill in all fields")),
      );
      return;
    }

    setState(() => isLoading = true);

    try {
// Firebase Auth ile kayıt ol
      final UserCredential userCred = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(email: email, password: password);
      // Firestore'a doktor bilgisi ekle
      await FirebaseFirestore.instance
          .collection('doctors')
          .doc(userCred.user!.uid)
          .set({
        'name': name,
        'email': email,
        'age': age,
        'department': department,
        'createdAt': Timestamp.now(),
      });

// Test çıktısı
      print("Firestore verisi eklendi. Yönlendiriliyor...");

      if (context.mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const WelcomePage()),
        );
      }
    } catch (e, stack) {
      print("Kayıt hatası: $e");
      print("Stacktrace: $stack");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Kayıt hatası: ${e.toString()}")),
      );
    } finally {
      if (mounted) {
        setState(() => isLoading = false);
      }
    }
  }
    }